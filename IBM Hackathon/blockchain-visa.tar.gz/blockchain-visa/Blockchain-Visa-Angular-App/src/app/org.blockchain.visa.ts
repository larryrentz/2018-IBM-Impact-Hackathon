import {Asset} from './org.hyperledger.composer.system';
import {Participant} from './org.hyperledger.composer.system';
import {Transaction} from './org.hyperledger.composer.system';
import {Event} from './org.hyperledger.composer.system';
// export namespace org.blockchain.visa{
   export class Visa extends Asset {
      visaId: string;
      issueDate: number;
      typeVisa: string;
      embassy: string;
      travellerId: number;
      validity: string;
      status: string;
      govt: Govt;
      traveler: Traveler;
   }
   export class Traveler extends Participant {
      participantId: string;
      primaryName: string;
      countryOfCitizen: string;
      schoolName: string;
      passportName: string;
      dateOfBirth: Date;
      formIssueReason: string;
   }
   export class Application extends Asset {
      applicationId: string;
      primaryName: string;
      applicationType: ApplicationType;
      relationshipStatus: RelationshipStatus;
      orginCitizenship: string;
      phoneNumber: string;
      hasBeenInUsBefore: boolean;
      approved: boolean;
      traveler: Traveler;
      govt: Govt;
   }
   export enum EducationLevel {
      ELEMENTARY,
      HIGHSCHOOL,
      BACHLOR,
   }
   export enum ApplicationType {
      STUDENT,
      WORK,
      TOURIST,
   }
   export enum RelationshipStatus {
      SINGLE,
      MARRIED,
      DIVORCED,
   }
   export class Govt extends Participant {
      govtId: string;
      govName: string;
      govtDepartmentNum: number;
      address: string;
      phone: string;
   }
   export class Apply extends Transaction {
      application: Application;
      govt: Govt;
   }
   export class Approve extends Transaction {
      application: Application;
      visa: Visa;
      traveler: Traveler;
   }
   export class Reject extends Transaction {
      application: Application;
      traveler: Traveler;
   }
   export class Update extends Transaction {
      application: Application;
      govt: Govt;
   }
// }
