/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { ApplicationService } from './Application.service';
import 'rxjs/add/operator/toPromise';

@Component({
  selector: 'app-application',
  templateUrl: './Application.component.html',
  styleUrls: ['./Application.component.css'],
  providers: [ApplicationService]
})
export class ApplicationComponent implements OnInit {

  myForm: FormGroup;

  private allAssets;
  private asset;
  private currentId;
  private errorMessage;

  applicationId = new FormControl('', Validators.required);
  primaryName = new FormControl('', Validators.required);
  applicationType = new FormControl('', Validators.required);
  relationshipStatus = new FormControl('', Validators.required);
  orginCitizenship = new FormControl('', Validators.required);
  phoneNumber = new FormControl('', Validators.required);
  hasBeenInUsBefore = new FormControl('', Validators.required);
  approved = new FormControl('', Validators.required);
  traveler = new FormControl('', Validators.required);
  govt = new FormControl('', Validators.required);

  constructor(public serviceApplication: ApplicationService, fb: FormBuilder) {
    this.myForm = fb.group({
      applicationId: this.applicationId,
      primaryName: this.primaryName,
      applicationType: this.applicationType,
      relationshipStatus: this.relationshipStatus,
      orginCitizenship: this.orginCitizenship,
      phoneNumber: this.phoneNumber,
      hasBeenInUsBefore: this.hasBeenInUsBefore,
      approved: this.approved,
      traveler: this.traveler,
      govt: this.govt
    });
  };

  ngOnInit(): void {
    this.loadAll();
  }

  loadAll(): Promise<any> {
    const tempList = [];
    return this.serviceApplication.getAll()
    .toPromise()
    .then((result) => {
      this.errorMessage = null;
      result.forEach(asset => {
        tempList.push(asset);
      });
      this.allAssets = tempList;
    })
    .catch((error) => {
      if (error === 'Server error') {
        this.errorMessage = 'Could not connect to REST server. Please check your configuration details';
      } else if (error === '404 - Not Found') {
        this.errorMessage = '404 - Could not find API route. Please check your available APIs.';
      } else {
        this.errorMessage = error;
      }
    });
  }

	/**
   * Event handler for changing the checked state of a checkbox (handles array enumeration values)
   * @param {String} name - the name of the asset field to update
   * @param {any} value - the enumeration value for which to toggle the checked state
   */
  changeArrayValue(name: string, value: any): void {
    const index = this[name].value.indexOf(value);
    if (index === -1) {
      this[name].value.push(value);
    } else {
      this[name].value.splice(index, 1);
    }
  }

	/**
	 * Checkbox helper, determining whether an enumeration value should be selected or not (for array enumeration values
   * only). This is used for checkboxes in the asset updateDialog.
   * @param {String} name - the name of the asset field to check
   * @param {any} value - the enumeration value to check for
   * @return {Boolean} whether the specified asset field contains the provided value
   */
  hasArrayValue(name: string, value: any): boolean {
    return this[name].value.indexOf(value) !== -1;
  }

  addAsset(form: any): Promise<any> {
    this.asset = {
      $class: 'org.blockchain.visa.Application',
      'applicationId': this.applicationId.value,
      'primaryName': this.primaryName.value,
      'applicationType': this.applicationType.value,
      'relationshipStatus': this.relationshipStatus.value,
      'orginCitizenship': this.orginCitizenship.value,
      'phoneNumber': this.phoneNumber.value,
      'hasBeenInUsBefore': this.hasBeenInUsBefore.value,
      'approved': this.approved.value,
      'traveler': this.traveler.value,
      'govt': this.govt.value
    };

    this.myForm.setValue({
      'applicationId': null,
      'primaryName': null,
      'applicationType': null,
      'relationshipStatus': null,
      'orginCitizenship': null,
      'phoneNumber': null,
      'hasBeenInUsBefore': null,
      'approved': null,
      'traveler': null,
      'govt': null
    });

    return this.serviceApplication.addAsset(this.asset)
    .toPromise()
    .then(() => {
      this.errorMessage = null;
      this.myForm.setValue({
        'applicationId': null,
        'primaryName': null,
        'applicationType': null,
        'relationshipStatus': null,
        'orginCitizenship': null,
        'phoneNumber': null,
        'hasBeenInUsBefore': null,
        'approved': null,
        'traveler': null,
        'govt': null
      });
      this.loadAll();
    })
    .catch((error) => {
      if (error === 'Server error') {
          this.errorMessage = 'Could not connect to REST server. Please check your configuration details';
      } else {
          this.errorMessage = error;
      }
    });
  }


  updateAsset(form: any): Promise<any> {
    this.asset = {
      $class: 'org.blockchain.visa.Application',
      'primaryName': this.primaryName.value,
      'applicationType': this.applicationType.value,
      'relationshipStatus': this.relationshipStatus.value,
      'orginCitizenship': this.orginCitizenship.value,
      'phoneNumber': this.phoneNumber.value,
      'hasBeenInUsBefore': this.hasBeenInUsBefore.value,
      'approved': this.approved.value,
      'traveler': this.traveler.value,
      'govt': this.govt.value
    };

    return this.serviceApplication.updateAsset(form.get('applicationId').value, this.asset)
    .toPromise()
    .then(() => {
      this.errorMessage = null;
      this.loadAll();
    })
    .catch((error) => {
      if (error === 'Server error') {
        this.errorMessage = 'Could not connect to REST server. Please check your configuration details';
      } else if (error === '404 - Not Found') {
        this.errorMessage = '404 - Could not find API route. Please check your available APIs.';
      } else {
        this.errorMessage = error;
      }
    });
  }


  deleteAsset(): Promise<any> {

    return this.serviceApplication.deleteAsset(this.currentId)
    .toPromise()
    .then(() => {
      this.errorMessage = null;
      this.loadAll();
    })
    .catch((error) => {
      if (error === 'Server error') {
        this.errorMessage = 'Could not connect to REST server. Please check your configuration details';
      } else if (error === '404 - Not Found') {
        this.errorMessage = '404 - Could not find API route. Please check your available APIs.';
      } else {
        this.errorMessage = error;
      }
    });
  }

  setId(id: any): void {
    this.currentId = id;
  }

  getForm(id: any): Promise<any> {

    return this.serviceApplication.getAsset(id)
    .toPromise()
    .then((result) => {
      this.errorMessage = null;
      const formObject = {
        'applicationId': null,
        'primaryName': null,
        'applicationType': null,
        'relationshipStatus': null,
        'orginCitizenship': null,
        'phoneNumber': null,
        'hasBeenInUsBefore': null,
        'approved': null,
        'traveler': null,
        'govt': null
      };

      if (result.applicationId) {
        formObject.applicationId = result.applicationId;
      } else {
        formObject.applicationId = null;
      }

      if (result.primaryName) {
        formObject.primaryName = result.primaryName;
      } else {
        formObject.primaryName = null;
      }

      if (result.applicationType) {
        formObject.applicationType = result.applicationType;
      } else {
        formObject.applicationType = null;
      }

      if (result.relationshipStatus) {
        formObject.relationshipStatus = result.relationshipStatus;
      } else {
        formObject.relationshipStatus = null;
      }

      if (result.orginCitizenship) {
        formObject.orginCitizenship = result.orginCitizenship;
      } else {
        formObject.orginCitizenship = null;
      }

      if (result.phoneNumber) {
        formObject.phoneNumber = result.phoneNumber;
      } else {
        formObject.phoneNumber = null;
      }

      if (result.hasBeenInUsBefore) {
        formObject.hasBeenInUsBefore = result.hasBeenInUsBefore;
      } else {
        formObject.hasBeenInUsBefore = null;
      }

      if (result.approved) {
        formObject.approved = result.approved;
      } else {
        formObject.approved = null;
      }

      if (result.traveler) {
        formObject.traveler = result.traveler;
      } else {
        formObject.traveler = null;
      }

      if (result.govt) {
        formObject.govt = result.govt;
      } else {
        formObject.govt = null;
      }

      this.myForm.setValue(formObject);

    })
    .catch((error) => {
      if (error === 'Server error') {
        this.errorMessage = 'Could not connect to REST server. Please check your configuration details';
      } else if (error === '404 - Not Found') {
        this.errorMessage = '404 - Could not find API route. Please check your available APIs.';
      } else {
        this.errorMessage = error;
      }
    });
  }

  resetForm(): void {
    this.myForm.setValue({
      'applicationId': null,
      'primaryName': null,
      'applicationType': null,
      'relationshipStatus': null,
      'orginCitizenship': null,
      'phoneNumber': null,
      'hasBeenInUsBefore': null,
      'approved': null,
      'traveler': null,
      'govt': null
      });
  }

}
