/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { TravelerService } from './Traveler.service';
import 'rxjs/add/operator/toPromise';

@Component({
  selector: 'app-traveler',
  templateUrl: './Traveler.component.html',
  styleUrls: ['./Traveler.component.css'],
  providers: [TravelerService]
})
export class TravelerComponent implements OnInit {

  myForm: FormGroup;

  private allParticipants;
  private participant;
  private currentId;
  private errorMessage;

  participantId = new FormControl('', Validators.required);
  primaryName = new FormControl('', Validators.required);
  countryOfCitizen = new FormControl('', Validators.required);
  schoolName = new FormControl('', Validators.required);
  passportName = new FormControl('', Validators.required);
  dateOfBirth = new FormControl('', Validators.required);
  formIssueReason = new FormControl('', Validators.required);


  constructor(public serviceTraveler: TravelerService, fb: FormBuilder) {
    this.myForm = fb.group({
      participantId: this.participantId,
      primaryName: this.primaryName,
      countryOfCitizen: this.countryOfCitizen,
      schoolName: this.schoolName,
      passportName: this.passportName,
      dateOfBirth: this.dateOfBirth,
      formIssueReason: this.formIssueReason
    });
  };

  ngOnInit(): void {
    this.loadAll();
  }

  loadAll(): Promise<any> {
    const tempList = [];
    return this.serviceTraveler.getAll()
    .toPromise()
    .then((result) => {
      this.errorMessage = null;
      result.forEach(participant => {
        tempList.push(participant);
      });
      this.allParticipants = tempList;
    })
    .catch((error) => {
      if (error === 'Server error') {
        this.errorMessage = 'Could not connect to REST server. Please check your configuration details';
      } else if (error === '404 - Not Found') {
        this.errorMessage = '404 - Could not find API route. Please check your available APIs.';
        this.errorMessage = error;
      }
    });
  }

	/**
   * Event handler for changing the checked state of a checkbox (handles array enumeration values)
   * @param {String} name - the name of the participant field to update
   * @param {any} value - the enumeration value for which to toggle the checked state
   */
  changeArrayValue(name: string, value: any): void {
    const index = this[name].value.indexOf(value);
    if (index === -1) {
      this[name].value.push(value);
    } else {
      this[name].value.splice(index, 1);
    }
  }

	/**
	 * Checkbox helper, determining whether an enumeration value should be selected or not (for array enumeration values
   * only). This is used for checkboxes in the participant updateDialog.
   * @param {String} name - the name of the participant field to check
   * @param {any} value - the enumeration value to check for
   * @return {Boolean} whether the specified participant field contains the provided value
   */
  hasArrayValue(name: string, value: any): boolean {
    return this[name].value.indexOf(value) !== -1;
  }

  addParticipant(form: any): Promise<any> {
    this.participant = {
      $class: 'org.blockchain.visa.Traveler',
      'participantId': this.participantId.value,
      'primaryName': this.primaryName.value,
      'countryOfCitizen': this.countryOfCitizen.value,
      'schoolName': this.schoolName.value,
      'passportName': this.passportName.value,
      'dateOfBirth': this.dateOfBirth.value,
      'formIssueReason': this.formIssueReason.value
    };

    this.myForm.setValue({
      'participantId': null,
      'primaryName': null,
      'countryOfCitizen': null,
      'schoolName': null,
      'passportName': null,
      'dateOfBirth': null,
      'formIssueReason': null
    });

    return this.serviceTraveler.addParticipant(this.participant)
    .toPromise()
    .then(() => {
      this.errorMessage = null;
      this.myForm.setValue({
        'participantId': null,
        'primaryName': null,
        'countryOfCitizen': null,
        'schoolName': null,
        'passportName': null,
        'dateOfBirth': null,
        'formIssueReason': null
      });
      this.loadAll(); 
    })
    .catch((error) => {
      if (error === 'Server error') {
        this.errorMessage = 'Could not connect to REST server. Please check your configuration details';
      } else {
        this.errorMessage = error;
      }
    });
  }


   updateParticipant(form: any): Promise<any> {
    this.participant = {
      $class: 'org.blockchain.visa.Traveler',
      'primaryName': this.primaryName.value,
      'countryOfCitizen': this.countryOfCitizen.value,
      'schoolName': this.schoolName.value,
      'passportName': this.passportName.value,
      'dateOfBirth': this.dateOfBirth.value,
      'formIssueReason': this.formIssueReason.value
    };

    return this.serviceTraveler.updateParticipant(form.get('participantId').value, this.participant)
    .toPromise()
    .then(() => {
      this.errorMessage = null;
      this.loadAll();
    })
    .catch((error) => {
      if (error === 'Server error') {
        this.errorMessage = 'Could not connect to REST server. Please check your configuration details';
      } else if (error === '404 - Not Found') {
        this.errorMessage = '404 - Could not find API route. Please check your available APIs.';
      } else {
        this.errorMessage = error;
      }
    });
  }


  deleteParticipant(): Promise<any> {

    return this.serviceTraveler.deleteParticipant(this.currentId)
    .toPromise()
    .then(() => {
      this.errorMessage = null;
      this.loadAll();
    })
    .catch((error) => {
      if (error === 'Server error') {
        this.errorMessage = 'Could not connect to REST server. Please check your configuration details';
      } else if (error === '404 - Not Found') {
        this.errorMessage = '404 - Could not find API route. Please check your available APIs.';
      } else {
        this.errorMessage = error;
      }
    });
  }

  setId(id: any): void {
    this.currentId = id;
  }

  getForm(id: any): Promise<any> {

    return this.serviceTraveler.getparticipant(id)
    .toPromise()
    .then((result) => {
      this.errorMessage = null;
      const formObject = {
        'participantId': null,
        'primaryName': null,
        'countryOfCitizen': null,
        'schoolName': null,
        'passportName': null,
        'dateOfBirth': null,
        'formIssueReason': null
      };

      if (result.participantId) {
        formObject.participantId = result.participantId;
      } else {
        formObject.participantId = null;
      }

      if (result.primaryName) {
        formObject.primaryName = result.primaryName;
      } else {
        formObject.primaryName = null;
      }

      if (result.countryOfCitizen) {
        formObject.countryOfCitizen = result.countryOfCitizen;
      } else {
        formObject.countryOfCitizen = null;
      }

      if (result.schoolName) {
        formObject.schoolName = result.schoolName;
      } else {
        formObject.schoolName = null;
      }

      if (result.passportName) {
        formObject.passportName = result.passportName;
      } else {
        formObject.passportName = null;
      }

      if (result.dateOfBirth) {
        formObject.dateOfBirth = result.dateOfBirth;
      } else {
        formObject.dateOfBirth = null;
      }

      if (result.formIssueReason) {
        formObject.formIssueReason = result.formIssueReason;
      } else {
        formObject.formIssueReason = null;
      }

      this.myForm.setValue(formObject);
    })
    .catch((error) => {
      if (error === 'Server error') {
        this.errorMessage = 'Could not connect to REST server. Please check your configuration details';
      } else if (error === '404 - Not Found') {
        this.errorMessage = '404 - Could not find API route. Please check your available APIs.';
      } else {
        this.errorMessage = error;
      }
    });

  }

  resetForm(): void {
    this.myForm.setValue({
      'participantId': null,
      'primaryName': null,
      'countryOfCitizen': null,
      'schoolName': null,
      'passportName': null,
      'dateOfBirth': null,
      'formIssueReason': null
    });
  }
}
