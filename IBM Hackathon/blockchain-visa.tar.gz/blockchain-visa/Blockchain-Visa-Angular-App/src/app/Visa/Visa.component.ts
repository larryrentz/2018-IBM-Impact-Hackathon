/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { VisaService } from './Visa.service';
import 'rxjs/add/operator/toPromise';

@Component({
  selector: 'app-visa',
  templateUrl: './Visa.component.html',
  styleUrls: ['./Visa.component.css'],
  providers: [VisaService]
})
export class VisaComponent implements OnInit {

  myForm: FormGroup;

  private allAssets;
  private asset;
  private currentId;
  private errorMessage;

  visaId = new FormControl('', Validators.required);
  issueDate = new FormControl('', Validators.required);
  typeVisa = new FormControl('', Validators.required);
  embassy = new FormControl('', Validators.required);
  travellerId = new FormControl('', Validators.required);
  validity = new FormControl('', Validators.required);
  status = new FormControl('', Validators.required);
  govt = new FormControl('', Validators.required);
  traveler = new FormControl('', Validators.required);

  constructor(public serviceVisa: VisaService, fb: FormBuilder) {
    this.myForm = fb.group({
      visaId: this.visaId,
      issueDate: this.issueDate,
      typeVisa: this.typeVisa,
      embassy: this.embassy,
      travellerId: this.travellerId,
      validity: this.validity,
      status: this.status,
      govt: this.govt,
      traveler: this.traveler
    });
  };

  ngOnInit(): void {
    this.loadAll();
  }

  loadAll(): Promise<any> {
    const tempList = [];
    return this.serviceVisa.getAll()
    .toPromise()
    .then((result) => {
      this.errorMessage = null;
      result.forEach(asset => {
        tempList.push(asset);
      });
      this.allAssets = tempList;
    })
    .catch((error) => {
      if (error === 'Server error') {
        this.errorMessage = 'Could not connect to REST server. Please check your configuration details';
      } else if (error === '404 - Not Found') {
        this.errorMessage = '404 - Could not find API route. Please check your available APIs.';
      } else {
        this.errorMessage = error;
      }
    });
  }

	/**
   * Event handler for changing the checked state of a checkbox (handles array enumeration values)
   * @param {String} name - the name of the asset field to update
   * @param {any} value - the enumeration value for which to toggle the checked state
   */
  changeArrayValue(name: string, value: any): void {
    const index = this[name].value.indexOf(value);
    if (index === -1) {
      this[name].value.push(value);
    } else {
      this[name].value.splice(index, 1);
    }
  }

	/**
	 * Checkbox helper, determining whether an enumeration value should be selected or not (for array enumeration values
   * only). This is used for checkboxes in the asset updateDialog.
   * @param {String} name - the name of the asset field to check
   * @param {any} value - the enumeration value to check for
   * @return {Boolean} whether the specified asset field contains the provided value
   */
  hasArrayValue(name: string, value: any): boolean {
    return this[name].value.indexOf(value) !== -1;
  }

  addAsset(form: any): Promise<any> {
    this.asset = {
      $class: 'org.blockchain.visa.Visa',
      'visaId': this.visaId.value,
      'issueDate': this.issueDate.value,
      'typeVisa': this.typeVisa.value,
      'embassy': this.embassy.value,
      'travellerId': this.travellerId.value,
      'validity': this.validity.value,
      'status': this.status.value,
      'govt': this.govt.value,
      'traveler': this.traveler.value
    };

    this.myForm.setValue({
      'visaId': null,
      'issueDate': null,
      'typeVisa': null,
      'embassy': null,
      'travellerId': null,
      'validity': null,
      'status': null,
      'govt': null,
      'traveler': null
    });

    return this.serviceVisa.addAsset(this.asset)
    .toPromise()
    .then(() => {
      this.errorMessage = null;
      this.myForm.setValue({
        'visaId': null,
        'issueDate': null,
        'typeVisa': null,
        'embassy': null,
        'travellerId': null,
        'validity': null,
        'status': null,
        'govt': null,
        'traveler': null
      });
      this.loadAll();
    })
    .catch((error) => {
      if (error === 'Server error') {
          this.errorMessage = 'Could not connect to REST server. Please check your configuration details';
      } else {
          this.errorMessage = error;
      }
    });
  }


  updateAsset(form: any): Promise<any> {
    this.asset = {
      $class: 'org.blockchain.visa.Visa',
      'issueDate': this.issueDate.value,
      'typeVisa': this.typeVisa.value,
      'embassy': this.embassy.value,
      'travellerId': this.travellerId.value,
      'validity': this.validity.value,
      'status': this.status.value,
      'govt': this.govt.value,
      'traveler': this.traveler.value
    };

    return this.serviceVisa.updateAsset(form.get('visaId').value, this.asset)
    .toPromise()
    .then(() => {
      this.errorMessage = null;
      this.loadAll();
    })
    .catch((error) => {
      if (error === 'Server error') {
        this.errorMessage = 'Could not connect to REST server. Please check your configuration details';
      } else if (error === '404 - Not Found') {
        this.errorMessage = '404 - Could not find API route. Please check your available APIs.';
      } else {
        this.errorMessage = error;
      }
    });
  }


  deleteAsset(): Promise<any> {

    return this.serviceVisa.deleteAsset(this.currentId)
    .toPromise()
    .then(() => {
      this.errorMessage = null;
      this.loadAll();
    })
    .catch((error) => {
      if (error === 'Server error') {
        this.errorMessage = 'Could not connect to REST server. Please check your configuration details';
      } else if (error === '404 - Not Found') {
        this.errorMessage = '404 - Could not find API route. Please check your available APIs.';
      } else {
        this.errorMessage = error;
      }
    });
  }

  setId(id: any): void {
    this.currentId = id;
  }

  getForm(id: any): Promise<any> {

    return this.serviceVisa.getAsset(id)
    .toPromise()
    .then((result) => {
      this.errorMessage = null;
      const formObject = {
        'visaId': null,
        'issueDate': null,
        'typeVisa': null,
        'embassy': null,
        'travellerId': null,
        'validity': null,
        'status': null,
        'govt': null,
        'traveler': null
      };

      if (result.visaId) {
        formObject.visaId = result.visaId;
      } else {
        formObject.visaId = null;
      }

      if (result.issueDate) {
        formObject.issueDate = result.issueDate;
      } else {
        formObject.issueDate = null;
      }

      if (result.typeVisa) {
        formObject.typeVisa = result.typeVisa;
      } else {
        formObject.typeVisa = null;
      }

      if (result.embassy) {
        formObject.embassy = result.embassy;
      } else {
        formObject.embassy = null;
      }

      if (result.travellerId) {
        formObject.travellerId = result.travellerId;
      } else {
        formObject.travellerId = null;
      }

      if (result.validity) {
        formObject.validity = result.validity;
      } else {
        formObject.validity = null;
      }

      if (result.status) {
        formObject.status = result.status;
      } else {
        formObject.status = null;
      }

      if (result.govt) {
        formObject.govt = result.govt;
      } else {
        formObject.govt = null;
      }

      if (result.traveler) {
        formObject.traveler = result.traveler;
      } else {
        formObject.traveler = null;
      }

      this.myForm.setValue(formObject);

    })
    .catch((error) => {
      if (error === 'Server error') {
        this.errorMessage = 'Could not connect to REST server. Please check your configuration details';
      } else if (error === '404 - Not Found') {
        this.errorMessage = '404 - Could not find API route. Please check your available APIs.';
      } else {
        this.errorMessage = error;
      }
    });
  }

  resetForm(): void {
    this.myForm.setValue({
      'visaId': null,
      'issueDate': null,
      'typeVisa': null,
      'embassy': null,
      'travellerId': null,
      'validity': null,
      'status': null,
      'govt': null,
      'traveler': null
      });
  }

}
